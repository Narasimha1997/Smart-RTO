from flask import Flask, jsonify, request
from flask_cors import CORS, cross_origin
import Utils_Mongo


#get an instance of DB:
db = Utils_Mongo.initializeDatabase()

app = Flask(__name__)
CORS(app)

@app.route('/add_user', methods = ['POST'])
@cross_origin()
def add_user():
    data = request.get_json()
    Utils.AddNewUser(
        uname = data['name'],
        password = data['password'],
        cache_reference = cache,
        db = db
    ).run()
    return jsonify({
        'success' : True
    })

@app.route('/simple_auth' , methods = ['POST'])
@cross_origin()
def simple_auth():

    data = request.get_json()
    return jsonify({
        'success' : True
    }) if Utils_Mongo.auth(data['name'], data['password'], db) else jsonify({
        'success' : False
    })

@app.route('/admin_auth', methods = ['POST'])
@cross_origin()
def admin_auth():
    data = request.get_json()
    success, region = Utils_Mongo.area_auth(data['area'], data['password'], db)
    return jsonify({
        'success' : success,
        'region' : region
    })
    
@app.route('/new_user', methods = ['POST'])
@cross_origin()
def add_new_user():
    data = request.get_json()['data']
    print(data)
    Utils_Mongo.add_new_user(data, db)
    return jsonify({
        'success' : True,
        'message' : 'Successful registration'
    })

@app.route('/get_user_by_area', methods = ['POST'])
@cross_origin()
def get_user_by_area():
    area = request.get_json()['area']
    return jsonify({
        'success' : True,
        'result' : Utils_Mongo.get_user_by_area(area, db)
    })

@app.route('/get_profile', methods = ['POST'])
@cross_origin()
def get_profile():
    user_id = request.get_json()['user_id']
    return jsonify(Utils_Mongo.get_profile(user_id, db))

@app.route('/upload_document', methods = ['POST'])
@cross_origin()
def upload_document():
    data = request.get_json()
    Utils_Mongo.upload_document(
        data['user_id'],
        data['document'],
        data['document_name'],
        data['file_name'],
        data['file_tag'],
        db
    )
    return jsonify({'success' : True})

@app.route('/get_single_document', methods = ['POST'])
def get_single_document():

    return jsonify(
        Utils_Mongo.get_single_document(
            request.get_json()['user_id'],
            request.get_json()['document_name'],
            db
        )
    )

@app.route('/get_documents_of_user', methods = ['POST'])
@cross_origin()
def get_documents_of_user():
    user_id = request.get_json()['user_id']
    return jsonify({
        'status' : 'ok',
        'doc_list' : Utils_Mongo.search_documents_by_user(user_id, db)
    })

app.run(host = '192.168.0.103')